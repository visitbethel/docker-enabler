from org.jolokia.client import J4pClient;
from org.jolokia.client.request import J4pReadRequest;
from org.jolokia.client.request import J4pReadResponse;
from javax.management import ObjectName;

client = None;

def getRcv(varName):
    rcv = runtimeContext.getVariable(varName)
    if rcv == None:
        return None;
    else:
        return rcv.getValue();
    
def getClient():
    global client
    if client == None :
        url=getRcv("JOLOKIA_URL");
        client =J4pClient(url);
    return client;
        
    
    
def usedMemory():
    obj_name= ObjectName("java.lang:type=Memory");
    request = J4pReadRequest(obj_name,["HeapMemoryUsage"]);
    request.setPath("used");
    response = getClient().execute(request);
    return str(response.get(0).getValue());

def peakThreadCount():
    obj_name=ObjectName("java.lang:type=Threading");
    request = J4pReadRequest(obj_name,["PeakThreadCount"]);
    response = getClient().execute(request);
    return str(response.get(0).getValue());

def uptime():
    obj_name = ObjectName("java.lang:type=Runtime");
    request = J4pReadRequest(obj_name,["Uptime"]);
    response = getClient().execute(request);
    return str(response.get(0).getValue());
    
def getStatistic(statName):
    statValue = 0.0;
    if statName == "USED_MEMORY" :
        statValue=usedMemory();
    elif statName == "PEAK_THREAD_COUNT":
        statValue = peakThreadCount();
    elif statName == "UPTIME":
        statValue = uptime();
    else:
        logger.warning('Unknown statistic: ' + statName);
        
    return statValue;