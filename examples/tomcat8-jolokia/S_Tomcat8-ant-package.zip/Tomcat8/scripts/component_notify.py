from com.datasynapse.fabric.admin.info import NotificationEngineInfo;
from com.datasynapse.fabric.admin import AdminManager;

def componentNotification(componentName, notificationEngineInfoList):
    logger.info("Notification from component '" + componentName + "'.");
    logger.info("Component engines located at :" + notificationEngineInfoList.toString());
    engineAdmin=AdminManager.getEngineAdmin();
    n= NotificationEngineInfo();
    for n in notificationEngineInfoList:
        engine_id=n.getEngineId();
        instance=n.getInstance();
        info=engineAdmin.getEngineInfo(engine_id,instance);
        alloc=info.getAllocationInfo();
        props=alloc.getProperties();
        logger.info("--------------properties are -----------------------");
        for p in props:
           logger.info(p.getName() + "=" + p.getValue())
        logger.info("-----------------------------------------------------");