from com.datasynapse.fabric.container import ArchiveDetail;
from jarray import array;
from java.lang import String;
def archiveDetect():
    return array([],ArchiveDetail);

def urlDetect():
    return array([],String);